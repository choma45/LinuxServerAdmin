#!/bin/bash

echo 'This is a test.'
echo

echo ' ________________________'
echo '/                        \'
echo '|                        |'
echo '| 야 !! 공부좀 해라!!!   |'
echo '|                        |'
echo '\________________________/'
echo '  \'
echo '   \'
echo '     (__)'
echo '     (oo)______'
echo '     (__)      )\'
echo '        ||---||  *'
echo '        ||   ||'
echo

